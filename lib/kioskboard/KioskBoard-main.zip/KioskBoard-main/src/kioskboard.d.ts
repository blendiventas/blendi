import KioskBoard from '../index.d';
export = KioskBoard;
export as namespace KioskBoard;
